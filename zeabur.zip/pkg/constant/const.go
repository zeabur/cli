package constant

const (
	ZeaburServerURL = "https://gateway.zeabur.com"
	WebsocketURL    = "wss://gateway.zeabur.com"
)
