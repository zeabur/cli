// Package webapp is used to start a local server to listen for the callback from the OAuth provider(only Authorization Code Grant Type).
// It needs to be run on the same device as the user's web browser.
// based on github.com/cli/oauth/webapp, thanks a lot.
package webapp
